i=0
while i<300000
  i+=1
  begin
    raise
  rescue
  end
end
