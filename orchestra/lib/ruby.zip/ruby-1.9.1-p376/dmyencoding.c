#define NO_LOCALE_CHARMAP 1
#include "encoding.c"
