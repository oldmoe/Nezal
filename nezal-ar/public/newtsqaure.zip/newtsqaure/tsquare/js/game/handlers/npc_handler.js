var NPCHandler = Class.create({
   
   npcs: null,
   scene: null,
   
   initialize: function(scene){
       this.scene = scene;
   },
   
   tick: function(){
       
   },
   
   
   
   
    
});