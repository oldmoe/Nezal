var CrowdHandler = Class.create(UnitHandler, {
   
   initialPositions : [{x:200,y:30},{x:200,y:100},{x:200,y:200}],
   crowdMembersPerColumn : 2,
   running: false,
    
});