var UnitHandler = Class.create({
   
   objects: null,
   incomming: null,
   scene: null,
   
   
   initialize: function(scene){
       this.incomming = [];
       this.objects = [];
       this.scene = scene;       
   },
   
   tick: function(){
       this.checkObjectsState();
       var self = this;
       this.objects.each(function(laneObjects){self.scene.tickObjects(laneObjects)})
   },
   
   add: function(elem){
       if(this.incomming[elem.lane] == null){
         this.incomming[elem.lane] = [];
         this.objects[elem.lane] = [];  
       } 
      this.incomming[elem.lane].push({'name':elem.name, x:elem.x*this.scene.view.tileWidth,y:elem.lane,options:{handler:this}})
   },
   
  checkObjectsState : function(){
    for (var i = 0; i < this.objects.length; i++) {
      for (var j = 0; this.objects[i] && j < this.objects[i].length; j++) {
         if(this.objects[i][j].dead){
           this.objects[i][j].destroy()
           this.objects[i].splice(j, 1)
           j--
         }  
      }
    }
    for(var i=0;i<this.incomming.length;i++){
      for(var j=0; this.incomming[i] && j<this.incomming[i].length;j++){
        if (this.incomming[i][j].x < this.scene.view.xPos + this.scene.view.width) {
          this.objects[i].push(this.scene.addObject(this.incomming[i][j]))
          this.incomming[i].splice(0, 1)
          j--;
        }
        else {
          break
        }
      }
    }
  },
   
   
    
});