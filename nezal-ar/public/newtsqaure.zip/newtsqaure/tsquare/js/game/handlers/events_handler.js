var EventsHandler = Class.create({
   
   scene: null,
   
   initialize: function(scene){
       this.scene = scene;
   },
   
   tick: function(){
       
   },
   
   
   
   
    
});