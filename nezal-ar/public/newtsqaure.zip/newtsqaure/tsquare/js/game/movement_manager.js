var MovementManager = Class.create({
  moves : [[0,0,0,0],[1,1,1,1],[0,1,0,1], [2]],
  UP : 0, DOWN : 1,
  move : [],
  movements : [],
  turnOn : false,
  ticksPassed : 0,
  totalMoveTicks : 0,
  moveLength : 0,
  extraSpeed : 0,
  lastMoveClicked : false,
  moveSpeed : 15,
  
  beatMoving: false,
  comboStart: false,
  currentCombos: 0,
  
  initialize : function(scene){
    this.scene = scene
    this.registerListeners()
    this.playSounds()
    this.scene.push(this)
  },
  
  playSounds : function(){
   if(this.ticksPassed > this.nextTick+10){
      this.reset()
   } 
   this.nextTick = this.moveSpeed-this.extraSpeed
   Sounds.play(Sounds.gameSounds.beat)
   var self = this
   $('beatFlash').show()
   var fadeDuration = (this.nextTick - 3)*this.scene.reactor.delay / 1000
   this.scene.reactor.push(0,function(){new Effect.Fade('beatFlash',{duration: fadeDuration})})
   this.scene.reactor.push(this.nextTick,function(){self.playSounds()})
  },
  
  reset : function(){
    this.turnOn = false;
    this.move = [];
    this.beatMoving = false;
    this.comboStart = false;
    this.currentCombos = 0
    var oldSpeed = this.scene.speed
    this.scene.speed = Math.max(3,this.scene.speed-3)
    if(oldSpeed > this.scene.maxSpeed/2 && this.scene.speed < this.scene.maxSpeed/2){
      this.scene.handlers.running = false
      this.scene.setCrowdMembersState("normal")
    } 
    if(this.scene.speed <= 3) this.scene.moving = false
    if(this.scene.speed < this.scene.maxSpeed/2)this.scene.running = false
    if(this.scene.energy > 0)this.scene.energy-=this.scene.energyIncrease
    this.extraSpeed = 0
    this.ticksPassed = 0
  },
  
  tick : function(){
    if(this.scene.beatMoving){
      this.ticksPassed = 0
      return
    }
    this.ticksPassed++
    this.totalMoveTicks++  
  },
  
  registerListeners  : function(){
    var self = this
    document.stopObserving('keydown')
    document.observe('keydown', function(e){
      if(self.scene.beatMoving){
        self.reset()
      }else if(self.scene.moving){
        self.scene.comboStart = true
      }
      var click = -1
      if (e.keyCode == 39) {
        click = 0
      }
      else if (e.keyCode == 37) {
          click = 1
      }else if (e.keyCode == 32) {
          click = 2
      }
      
      if(!self.turnOn) self.turnOn = true
      console.log(self.ticksPassed, self.nextTick)
       if(click!=-1 && self.ticksPassed >= self.nextTick-10 && self.ticksPassed <= self.nextTick+10){		
            console.log('=')
      		  self.move.push(click)
      		  self.moveLength++
      }else if(self.ticksPassed <  self.nextTick-10){
            console.log('<')
            self.reset()
            self.moveLength = 1
      		  self.move = [click]
            self.totalMoveTicks =0
      }else if(self.ticksPassed > self.ticksPassed <= self.nextTick+10){
            console.log('>')
            self.reset()
            self.moveLength = 1
			      self.move = [click]
            self.totalMoveTicks =0
      }else{
            alert('!!!')            
      }
      self.checkMove()
      self.ticksPassed = 0
  		if(e.keyCode == 49){
        self.extraSpeed = 0
        self.playSounds(0,0)
      }else if(e.keyCode == 50){
        self.extraSpeed = 0
        self.playSounds(1,0)
      }else if(e.keyCode == 51){
        self.extraSpeed = 0
        self.playSounds(2,0)
      }
		})
  },
  
  getNextMoveIndex : function(){
    return 0
  },
  
  checkMove : function(){
  	var index = 0
    var found = false
    var moveIndex = this.getNextMoveIndex()
    var self = this
    var found  = false
    var moveIndex = 0
   for (moveIndex = 0; moveIndex < this.moves.length; moveIndex++) {
     var m = this.moves[moveIndex]
     found = true
     for (var i = 0; i < self.moveLength; i++) {
       if (self.move[i] != m[i]) {
         found = false
         break
       }
     }
     if(found){
       break
     }
   }
   console.log(this.move)
   if(!found){
     self.reset()
     return
   }
   var m = this.moves[moveIndex]
   if(m.length==self.move.length){
     this.move=[]
     this.moveLength = 0
     this.scene.startMove(moveIndex,self.nextTick*m.length)
     Sounds.play(Sounds.gameSounds.correct_move)
   }
  },
  
  startMove : function(commandIndex,noOfTicks){
    if(this.conversationOn) return
    var moves = {forward:0,backward:1,rotating:2, holding:3}
    var collision = this.detectCollisions()
    if(commandIndex == moves.forward){
      this.moveBack = false
      if(collision){
        this.moving = false
        return
      }else{
        this.moving = this.beatMoving = true    
      }
    }else if(commandIndex == moves.backward){
        this.moveBack = true
        this.moving = this.beatMoving = true
    }else if(commandIndex == moves.rotating){
      if (collision) {
        this.beatMoving = true
        this.rotating = true
        this.rotateObjects(collision)
      }
    }else if(commandIndex == moves.holding){
        this.beatMoving = false
        this.holding = true
        this.holdObjects(collision)
    }

    var self = this
    this.moves++
    this.reactor.push(noOfTicks, function(){
      self.moveEnd()
    })
    
  },

  moveEnd : function(){
    if(this.comboStart){
        this.comboStart= false
        this.combos++
        if (this.speed < this.maxSpeed) {
          var oldSpeed = this.speed
          this.speed += 3
          if(this.speed > this.maxSpeed / 2 && oldSpeed < this.maxSpeed / 2){
            this.setCrowdMembersState("run")
            this.running = true
          } 
        }
        if(this.movementManager.extraSpeed<9)this.movementManager.extraSpeed+=2
        this.currentCombos++ 
        this.createNextFollower()
      }
      this.beatMoving = false
      if(this.energy < this.maxEnergy)this.energy+=this.energyIncrease
      if (this.currentCombos % 2 == 0 && this.currentCombos > 0) {
      }
    
  },
  
});
