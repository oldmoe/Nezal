var templatesData = ''
