var Ultras = Class.create(CrowdMember,{
  
})
