var Journalist = Class.create(CrowdMember,{
  
})
