var DehydratorDisplay = Class.create(CrowdMemberDisplay,{
  initImages : function(){
    this.characterImg = Loader.images.characters['dehydrator.png'];
  }
})
