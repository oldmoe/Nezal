var TsquareScene = Class.create(Scene,{
    
    handlers: null,
    skyline: null,
    speed : 3,
    maxSpeed : 20,
    view: {width: 760, height: 410, xPos: 0, tileWidth: 50, laneMiddle : 28},
    
    
    initialize: function($super){
        $super();
        this.createRenderLoop('skyline',1);
        this.createRenderLoop('characters',2);
        
        this.handlers = {
            "crowd" : new CrowdHandler(this),
            "enemy" : new EnemyHandler(this)
        };  
        
        this.movementManager = new MovementManager(this)
               
        var self = this;
        self.data = gameData.data;
        self.noOfLanes = self.data.length;
        for(var i =0;i<self.data.length;i++){
            for(var j=0;j<self.data[i].length;j++){
                var elem = self.data[i][j]
                if(this.handlers[elem.category])
                    this.handlers[elem.category].add(elem);
            }
        }
    },
    
    init: function(){
        this.skyLine = new SkyLine(this)
    },
    
    
    tick: function(){
        for(var handler in this.handlers){
            this.handlers[handler].tick();
        }
    },

  addObject : function(objHash){
     var klassName = objHash.name.formClassName()
     var klass = eval(klassName)
     var obj = new klass(this,objHash.x - this.view.xPos,objHash.y,objHash.options)
     var displayKlass = eval(klassName + "Display")
     var objDisplay = new displayKlass(obj)
     if (!obj.noDisplay) {
       this.pushToRenderLoop('characters', objDisplay)
     }
     return obj
  },
  
  tickObjects : function(objects){
    try{
            var remainingObjects = []
            var self = this
            objects.each(function(object){
                if(!object.finished){
                    object.tick()
                    remainingObjects.push(object)
                }
            })
            objects = remainingObjects
        }catch(x){//console.log(x)
        }
        return this
  }
  
});