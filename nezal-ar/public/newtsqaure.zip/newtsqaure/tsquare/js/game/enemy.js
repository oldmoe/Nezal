var Enemy = Class.create(Unit, {
	
  initialize : function($super,scene,x,y){
     $super(scene,x,y) 
  },
  
  tick: function($super){
  	$super();
  }
});