var gameData = 

{"data":[[],[{"name":"journalist","category":"crowd","index":0,"lane":1,"x":0,"order":0},
    {"name":"journalist","category":"crowd","index":0,"lane":1,"x":1,"order":0},
    {"name":"journalist","category":"crowd","index":0,"lane":1,"x":2,"order":0},
    // {"name":"amn_markazy","category":"enemy","index":0,"lane":1,"x":14,"order":0},
    {"name":"charging_amn_markazy","category":"enemy","index":0,"lane":1,"x":14,"order":0},
/*   {
    "name": "block",
    "category": "enemy",
    "rows": 3,
    "columns" : 2,
    "object" : "amn_markazy",
    "lane": 1,
    "x": 10,
    "index": 0
  },*/
  {"name":"amn_markazy","category":"enemy","index":0,"lane":1,"x":1000,"order":3}]],
  "backgrounds":[[{"name":"skyline.png"}],[{"name":"skyline.png"}],[{"name":"sky1.png"}]],
  "environment":"day","gameModes":["normal"]}