var Salafi = Class.create(CrowdMember,{
  
})
